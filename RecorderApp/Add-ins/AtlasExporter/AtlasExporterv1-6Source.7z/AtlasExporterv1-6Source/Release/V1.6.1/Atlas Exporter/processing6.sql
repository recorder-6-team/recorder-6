IF OBJECT_ID('tempdb..#output') IS NOT NULL
  DROP TABLE #output
  
SELECT tlikey, grid, outputsys,
  CASE LEFT(selaggvalue,2)
    WHEN '12' THEN 'I' 
    WHEN '11' THEN '*'
    WHEN '10' THEN 'Z'
    WHEN '09' THEN 'E'
    WHEN '08' THEN 'W'
    WHEN '07' THEN 'S'
    WHEN '06' THEN 'U'
    WHEN '05' THEN 'K'
    WHEN '04' THEN 'A'
    WHEN '02' THEN '+'
  END as [status],
  CASE RIGHT(selaggvalue,1) WHEN '-' THEN '' ELSE RIGHT(selaggvalue,1) END AS rast_un
INTO #output
FROM #mapexpsym