DECLARE @date_start INT
SELECT @date_start=MIN(su.from_vague_date_start)
FROM #interim i
INNER JOIN Sample s ON s.sample_key=i.sample_key
INNER JOIN Survey_Event se ON se.Survey_Event_Key=s.Survey_Event_Key
INNER JOIN Survey su ON su.Survey_Key=se.Survey_Key

UPDATE i
  SET i.selvalue = 
  ((((CAST(i.date_from AS BIGINT)-@date_start)
   + ((CAST(i.date_to AS BIGINT)-CAST(i.date_to AS BIGINT))/2))
     *10000000)
   + (CAST(date_to AS BIGINT) - @date_start))
  *100 
  +
  CASE i.rast_un
    WHEN 'U' then 0
    WHEN 'N' then 20
    WHEN 'S' then 20
    WHEN 'O' then 20
    WHEN 'W' then 20
    WHEN 'E' then 20
    ELSE 40
  END 
  +
  CASE i.status
    WHEN 'I' then 8
    WHEN 'X' then 7
    WHEN '*' then 7
    WHEN 'Z' then 5
    WHEN 'E' then 3
    WHEN 'W' then 6
    WHEN 'S' then 2
    WHEN 'U' then 1
    WHEN 'K' then 0
    WHEN 'A' then 4
    WHEN '+' then 12
    WHEN '0' then 12
  END,
  aggvalue = CASE i.status
    WHEN 'I' then '12'
    WHEN 'X' then '11'
    WHEN '*' then '11'
    WHEN 'Z' then '10'
    WHEN 'E' then '09'
    WHEN 'W' then '08'
    WHEN 'S' then '07'
    WHEN 'U' then '06'
    WHEN 'K' then '05'
    WHEN 'A' then '04'
    WHEN '+' then '02'
    WHEN '0' then '02'
  END
FROM #interim i
INNER JOIN Sample s ON s.sample_key=i.sample_key
INNER JOIN Survey_Event se ON se.Survey_Event_Key=s.Survey_Event_Key
INNER JOIN Survey su ON su.Survey_Key=se.Survey_Key