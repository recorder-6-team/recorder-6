-- Reduce the output precision according to the user selection
UPDATE #mapexpint SET Grid = LEFT(Grid, #outputprecision# + 4)