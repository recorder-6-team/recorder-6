-- Build a table to pick up just the highest values for each distinct grid
IF OBJECT_ID('tempdb..#mapexpsym') IS NOT NULL
  DROP TABLE #mapexpsym

CREATE TABLE #mapexpsym 
  (tlikey CHAR(16), grid CHAR(7), outputsys VARCHAR(4), selaggvalue CHAR(15))

--
INSERT INTO #mapexpsym
  SELECT tlikey, grid, outputsys,
    -- agg_value(2) + date part of selvalue(n) + rast_un(1)
    MAX(SUBSTRING(selaggvalue,LEN(selaggvalue)-2,2)+LEFT(selaggvalue,12)+RIGHT(selaggvalue,1))
  FROM #mapexpint
  GROUP BY tlikey, grid, outputsys