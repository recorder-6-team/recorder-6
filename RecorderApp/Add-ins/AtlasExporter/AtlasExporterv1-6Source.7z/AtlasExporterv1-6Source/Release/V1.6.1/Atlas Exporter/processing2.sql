IF OBJECT_ID('tempdb..#mapexpint') IS NOT NULL
  DROP TABLE #mapexpint
  
CREATE TABLE #mapexpint 
  (TLIKey CHAR(16), grid CHAR(7), outputsys VARCHAR(4), selaggvalue CHAR(18))

-- this pads the selvalue with leading zeros. So we get 15 chars of selvalue, plus 2 chars of aggvalue, plus rast_un or - if not set.
INSERT INTO #mapexpint
SELECT Taxon_List_Item_Key, MTBQ, outputsys, MAX(replace(str(selvalue,15),' ','0') + aggvalue + CASE rast_un WHEN '' THEN '-' ELSE rast_un END)
FROM #interim
GROUP BY Taxon_List_Item_Key, MTBQ, outputsys