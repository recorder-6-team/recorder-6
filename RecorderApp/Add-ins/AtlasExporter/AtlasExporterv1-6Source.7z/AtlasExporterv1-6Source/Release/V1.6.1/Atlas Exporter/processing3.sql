-- Remove any coarser squares when there is a finer square available that is more recent. This can be overridden by the discardconflict setting.
DELETE m
FROM #mapexpint m
 WHERE EXISTS 
 (SELECT * from #mapexpint l
  WHERE l.tlikey=m.tlikey
  AND l.grid LIKE (RTRIM(m.grid)+'%') 
  AND l.grid<>m.grid
  AND (m.selaggvalue<=l.selaggvalue or #discardconflicts#=1))
  
-- now that we have processed coarse vs fine grids, we can reduce the grid precision
UPDATE #mapexpint
SET grid=LEFT(grid, 4+#outputprecision#)